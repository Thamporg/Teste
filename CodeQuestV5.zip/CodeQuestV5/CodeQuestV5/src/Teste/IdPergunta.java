package Teste;

import javax.swing.JOptionPane;

public class IdPergunta extends javax.swing.JFrame {
    public static int idPergunta = 1;  // ID da pergunta atual
    public static int pontuacao = 0;  // ID da pergunta atual
    public static int pontFinal = 0;
}
